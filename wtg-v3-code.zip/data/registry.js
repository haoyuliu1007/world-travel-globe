(function (global) {
  'use strict';

  const CONTINENTS = [
    {
      id: 'global',
      name: '全球总览',
      icon: '🌍',
      center: [72.0, 22.0],
      zoom: 1.55,
      pitch: 14,
      round: '全球七大洲全面封神 · 137 国/地区 722 城 5,414 机位',
      status: 'active',
      plannedCountries: ['亚洲 41 国 245 城（已点亮）', '欧洲 26 国/地区 133 城（已点亮）', '大洋洲 8 国 48 城（已点亮）', '北美洲 18 国/地区 128 城（已点亮）', '南美洲 10 国 74 城（已点亮）', '非洲 / 南极 35 国/地区 94 城（已点亮）']
    },
    {
      id: 'asia',
      name: '亚洲',
      icon: '🏯',
      center: [95.0, 26.0],
      zoom: 2.15,
      pitch: 16,
      round: '第一轮全境封神 · 41 国/地区 245 城 1,574 个精准机位',
      status: 'active',
      plannedCountries: [
        { name: '中国', done: true },
        { name: '日本', done: true },
        { name: '韩国', done: true },
        { name: '蒙古', done: true },
        { name: '俄罗斯', done: true },
        { name: '巴基斯坦', done: true },
        { name: '新加坡', done: true },
        { name: '泰国', done: true },
        { name: '马来西亚', done: true },
        { name: '印度尼西亚', done: true },
        { name: '越南', done: true },
        { name: '菲律宾', done: true },
        { name: '柬埔寨', done: true },
        { name: '老挝', done: true },
        { name: '缅甸', done: true },
        { name: '文莱', done: true },
        { name: '马尔代夫', done: true },
        { name: '斯里兰卡', done: true },
        { name: '尼泊尔', done: true },
        { name: '不丹', done: true },
        { name: '印度', done: true },
        { name: '伊朗', done: true },
        { name: '阿联酋', done: true },
        { name: '卡塔尔', done: true },
        { name: '巴林', done: true },
        { name: '科威特', done: true },
        { name: '阿曼', done: true },
        { name: '也门', done: true },
        { name: '约旦', done: true },
        { name: '沙特阿拉伯', done: true },
        { name: '以色列', done: true },
        { name: '塞浦路斯', done: true },
        { name: '土耳其', done: true },
        { name: '格鲁吉亚', done: true },
        { name: '阿塞拜疆', done: true },
        { name: '亚美尼亚', done: true },
        { name: '乌兹别克斯坦', done: true },
        { name: '哈萨克斯坦', done: true },
        { name: '吉尔吉斯斯坦', done: true },
        { name: '土库曼斯坦', done: true },
        { name: '塔吉克斯坦', done: true }
      ]
    },
    {
      id: 'europe',
      name: '欧洲',
      icon: '🏰',
      center: [12.5, 50.5],
      zoom: 2.75,
      pitch: 18,
      round: '第二轮全面点亮 · 26 国/地区 133 城 1,078 个精准机位',
      status: 'active',
      plannedCountries: [
        { name: '冰岛', done: true },
        { name: '法罗群岛', done: true },
        { name: '挪威', done: true },
        { name: '瑞典', done: true },
        { name: '芬兰', done: true },
        { name: '丹麦', done: true },
        { name: '瑞士', done: true },
        { name: '意大利', done: true },
        { name: '梵蒂冈', done: true },
        { name: '奥地利', done: true },
        { name: '德国', done: true },
        { name: '斯洛文尼亚', done: true },
        { name: '希腊', done: true },
        { name: '捷克', done: true },
        { name: '匈牙利', done: true },
        { name: '波兰', done: true },
        { name: '西班牙', done: true },
        { name: '葡萄牙', done: true },
        { name: '克罗地亚', done: true },
        { name: '黑山', done: true },
        { name: '法国', done: true },
        { name: '荷兰', done: true },
        { name: '比利时', done: true },
        { name: '英国', done: true },
        { name: '爱尔兰', done: true },
        { name: '俄罗斯', done: true }
      ]
    },
    {
      id: 'oceania',
      name: '大洋洲',
      icon: '🦘',
      center: [148.0, -25.0],
      zoom: 2.45,
      pitch: 16,
      round: '第三轮全面点亮 · 8 国/地区 48 城 386 个精准机位',
      status: 'active',
      plannedCountries: [
        { name: '新西兰', done: true },
        { name: '澳大利亚', done: true },
        { name: '法属波利尼西亚', done: true },
        { name: '帕劳', done: true },
        { name: '斐济', done: true },
        { name: '瓦努阿图', done: true },
        { name: '库克群岛', done: true },
        { name: '新喀里多尼亚', done: true }
      ]
    },
    {
      id: 'north_america',
      name: '北美洲',
      icon: '🦅',
      center: [-101.0, 41.0],
      zoom: 2.35,
      pitch: 16,
      round: '第四轮全面点亮 · 18 国/地区 128 城 1,032 个精准机位',
      status: 'active',
      plannedCountries: [
        { name: '加拿大', done: true },
        { name: '格陵兰', done: true },
        { name: '美国', done: true },
        { name: '墨西哥', done: true },
        { name: '哥斯达黎加', done: true },
        { name: '危地马拉', done: true },
        { name: '伯利兹', done: true },
        { name: '尼加拉瓜', done: true },
        { name: '古巴', done: true },
        { name: '巴拿马', done: true },
        { name: '波多黎各', done: true },
        { name: '巴哈马', done: true },
        { name: '圣卢西亚', done: true },
        { name: '特克斯和凯科斯群岛', done: true },
        { name: '英属维尔京群岛', done: true },
        { name: '阿鲁巴', done: true },
        { name: '库拉索', done: true },
        { name: '百慕大', done: true }
      ]
    },
    {
      id: 'south_america',
      name: '南美洲',
      icon: '🦙',
      center: [-63.0, -21.0],
      zoom: 2.35,
      pitch: 16,
      round: '第五轮全面点亮 · 10 国 74 城 592 个精准机位',
      status: 'active',
      plannedCountries: [
        { name: '秘鲁', done: true },
        { name: '厄瓜多尔', done: true },
        { name: '玻利维亚', done: true },
        { name: '智利', done: true },
        { name: '阿根廷', done: true },
        { name: '乌拉圭', done: true },
        { name: '巴西', done: true },
        { name: '委内瑞拉', done: true },
        { name: '圭亚那', done: true },
        { name: '哥伦比亚', done: true }
      ]
    },
    {
      id: 'africa_antarctica',
      name: '非洲 / 南极',
      icon: '🦁',
      center: [22.0, -18.0],
      zoom: 2.05,
      pitch: 16,
      round: '第六轮收官封神 · 35 国/地区 94 城 752 个精准机位',
      status: 'active',
      plannedCountries: [
        { name: '肯尼亚', done: true },
        { name: '坦桑尼亚', done: true },
        { name: '乌干达', done: true },
        { name: '卢旺达', done: true },
        { name: '埃塞俄比亚', done: true },
        { name: '吉布提', done: true },
        { name: '纳米比亚', done: true },
        { name: '博茨瓦纳', done: true },
        { name: '赞比亚', done: true },
        { name: '津巴布韦', done: true },
        { name: '马拉维', done: true },
        { name: '南非', done: true },
        { name: '莱索托', done: true },
        { name: '莫桑比克', done: true },
        { name: '马达加斯加', done: true },
        { name: '塞舌尔', done: true },
        { name: '毛里求斯', done: true },
        { name: '留尼汪', done: true },
        { name: '科摩罗', done: true },
        { name: '摩洛哥', done: true },
        { name: '突尼斯', done: true },
        { name: '阿尔及利亚', done: true },
        { name: '毛里塔尼亚', done: true },
        { name: '埃及', done: true },
        { name: '苏丹', done: true },
        { name: '佛得角', done: true },
        { name: '塞内加尔', done: true },
        { name: '加纳', done: true },
        { name: '圣多美和普林西比', done: true },
        { name: '乍得', done: true },
        { name: '喀麦隆', done: true },
        { name: '加蓬', done: true },
        { name: '南极洲', done: true },
        { name: '南乔治亚和南桑威奇群岛', done: true },
        { name: '福克兰群岛', done: true }
      ]
    }
  ];

  const REGION_ORDER = [
    '华北与京津晋蒙',
    '东北冰雪与林海',
    '华东江南与名山海岛',
    '华中奇峰与峡谷',
    '华南山水与热带海岛',
    '西南雪山秘境与彩林',
    '西北大漠丝路与西域',
    '港澳台',
    '日本建筑与四季秘境',
    '韩国与蒙古高原',
    '新马印尼菲海上明珠',
    '中南半岛佛国与山海',
    '南亚印度洋与喜马拉雅',
    '中东未来沙漠与玫瑰古城',
    '土耳其高加索与中亚丝路',
    '北亚与喀喇昆仑极境',
    '西亚波斯与阿拉伯奇观',
    '北欧冰川峡湾与极光',
    '阿尔卑斯雪山与多洛米蒂',
    '意大利与地中海古文明',
    '伊比利亚与亚得里亚海岸',
    '西欧浪漫花海与建筑都会',
    '英伦高地与大西洋断崖',
    '俄欧极光、古都与高加索雪巅',
    '新西兰南岛与北岛奇境',
    '澳大利亚荒野海岸与红土',
    '南太平洋蓝海秘境群岛',
    '加拿大落基山与极地冰原',
    '美国西部国家公园与荒野奇观',
    '美国夏威夷与东西岸经典',
    '墨西哥、中美洲与加勒比奇迹',
    '安第斯印加文明与秘鲁神迹',
    '玻利维亚天空之镜与智利阿塔卡马',
    '巴塔哥尼亚世界尽头与冰川尖峰',
    '巴西热带奇迹与亚马孙',
    '哥伦比亚安第斯彩谷与加勒比海岸',
    '东非大裂谷与野生动物大迁徙',
    '南部非洲红沙漠与巨瀑奇观',
    '马达加斯加与印度洋梦幻群岛',
    '北非撒哈拉沙海与摩洛哥奇境',
    '古埃及文明与红海西非秘境',
    '南极大陆与亚南极极地终章'
  ];

  const REGION_META = {
    '华北与京津晋蒙': { icon: '🏯', color: '#f59e0b' },
    '东北冰雪与林海': { icon: '❄️', color: '#38bdf8' },
    '华东江南与名山海岛': { icon: '🎋', color: '#34d399' },
    '华中奇峰与峡谷': { icon: '⛰️', color: '#a78bfa' },
    '华南山水与热带海岛': { icon: '🌴', color: '#2dd4bf' },
    '西南雪山秘境与彩林': { icon: '🏔️', color: '#fb7185' },
    '西北大漠丝路与西域': { icon: '🐪', color: '#fb923c' },
    '港澳台': { icon: '🌆', color: '#f472b6' },
    '日本建筑与四季秘境': { icon: '⛩️', color: '#f472b6' },
    '韩国与蒙古高原': { icon: '🐎', color: '#60a5fa' },
    '新马印尼菲海上明珠': { icon: '🌋', color: '#2dd4bf' },
    '中南半岛佛国与山海': { icon: '🛕', color: '#fbbf24' },
    '南亚印度洋与喜马拉雅': { icon: '🏝️', color: '#38bdf8' },
    '中东未来沙漠与玫瑰古城': { icon: '🕌', color: '#fb923c' },
    '土耳其高加索与中亚丝路': { icon: '🎈', color: '#c084fc' },
    '北亚与喀喇昆仑极境': { icon: '🧊', color: '#38bdf8' },
    '西亚波斯与阿拉伯奇观': { icon: '🏜️', color: '#f59e0b' },
    '北欧冰川峡湾与极光': { icon: '🌌', color: '#60a5fa' },
    '阿尔卑斯雪山与多洛米蒂': { icon: '🏔️', color: '#38bdf8' },
    '意大利与地中海古文明': { icon: '🏛️', color: '#f59e0b' },
    '伊比利亚与亚得里亚海岸': { icon: '⛵', color: '#fb7185' },
    '西欧浪漫花海与建筑都会': { icon: '🗼', color: '#c084fc' },
    '英伦高地与大西洋断崖': { icon: '🏰', color: '#a78bfa' },
    '俄欧极光、古都与高加索雪巅': { icon: '⛪', color: '#fb7185' },
    '新西兰南岛与北岛奇境': { icon: '🥝', color: '#34d399' },
    '澳大利亚荒野海岸与红土': { icon: '🦘', color: '#fb923c' },
    '南太平洋蓝海秘境群岛': { icon: '🌺', color: '#2dd4bf' },
    '加拿大落基山与极地冰原': { icon: '🍁', color: '#38bdf8' },
    '美国西部国家公园与荒野奇观': { icon: '🏜️', color: '#fb923c' },
    '美国夏威夷与东西岸经典': { icon: '🗽', color: '#f472b6' },
    '墨西哥、中美洲与加勒比奇迹': { icon: '🌮', color: '#2dd4bf' },
    '安第斯印加文明与秘鲁神迹': { icon: '🦙', color: '#f59e0b' },
    '玻利维亚天空之镜与智利阿塔卡马': { icon: '🪞', color: '#60a5fa' },
    '巴塔哥尼亚世界尽头与冰川尖峰': { icon: '🏔️', color: '#a78bfa' },
    '巴西热带奇迹与亚马孙': { icon: '🌴', color: '#34d399' },
    '哥伦比亚安第斯彩谷与加勒比海岸': { icon: '🌈', color: '#fb7185' },
    '东非大裂谷与野生动物大迁徙': { icon: '🦁', color: '#f59e0b' },
    '南部非洲红沙漠与巨瀑奇观': { icon: '🏜️', color: '#fb923c' },
    '马达加斯加与印度洋梦幻群岛': { icon: '🌺', color: '#2dd4bf' },
    '北非撒哈拉沙海与摩洛哥奇境': { icon: '🐪', color: '#fb7185' },
    '古埃及文明与红海西非秘境': { icon: '🏺', color: '#a78bfa' },
    '南极大陆与亚南极极地终章': { icon: '🐧', color: '#38bdf8' }
  };

  const destinations = [];
  const byId = new Map();
  const regionFetchCache = new Map();

  function registerDestinations(list) {
    if (!Array.isArray(list)) return;
    list.forEach((item) => {
      if (!item || !item.id) return;
      if (byId.has(item.id)) {
        const idx = destinations.findIndex((d) => d.id === item.id);
        if (idx !== -1) destinations[idx] = item;
      } else {
        destinations.push(item);
      }
      byId.set(item.id, item);
    });
  }

  function ensureDetail(id) {
    const cur = byId.get(id);
    if (!cur) return Promise.resolve(null);
    if (Array.isArray(cur.spots)) {
      return Promise.resolve(cur);
    }
    const rIdx = cur._r;
    if (rIdx === undefined || rIdx === null) {
      return Promise.resolve(cur);
    }
    cur._detailFailed = false;
    if (!regionFetchCache.has(rIdx)) {
      const loadViaScript = () =>
        new Promise((resolve) => {
          const s = document.createElement('script');
          s.src = `data/regions/r${rIdx}.js`;
          s.async = true;
          s.onload = () => resolve(byId.get(id) || null);
          s.onerror = () => resolve(null);
          document.head.appendChild(s);
        });

      const fetchJsonWithTimeout = (url, ms) => {
        const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
        const timer = ctrl ? setTimeout(() => ctrl.abort(), ms) : null;
        return fetch(url, ctrl ? { signal: ctrl.signal } : undefined)
          .then((res) => {
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            return res.json();
          })
          .finally(() => {
            if (timer) clearTimeout(timer);
          });
      };

      const fetchWithRetry = () =>
        fetchJsonWithTimeout(`data/regions/r${rIdx}.json`, 8000).catch(() =>
          new Promise((r) => setTimeout(r, 450)).then(() =>
            fetchJsonWithTimeout(`data/regions/r${rIdx}.json`, 10000)
          )
        );

      const p =
        global.location && global.location.protocol === 'file:'
          ? loadViaScript()
          : fetchWithRetry()
              .then((items) => {
                registerDestinations(items);
                return byId.get(id) || null;
              })
              .catch(() => loadViaScript())
              .then((resolved) => {
                const latest = resolved || byId.get(id);
                if (!latest || !Array.isArray(latest.spots)) {
                  regionFetchCache.delete(rIdx);
                  if (latest) latest._detailFailed = true;
                }
                return latest || null;
              });
      regionFetchCache.set(rIdx, p);
    }
    return regionFetchCache.get(rIdx).then(() => {
      const latest = byId.get(id) || null;
      if (latest && !Array.isArray(latest.spots)) {
        regionFetchCache.delete(rIdx);
        latest._detailFailed = true;
      }
      return latest;
    });
  }

  global.TRAVEL_ATLAS = {
    CONTINENTS: CONTINENTS,
    REGION_ORDER: REGION_ORDER,
    REGION_META: REGION_META,
    registerDestinations: registerDestinations,
    ensureDetail: ensureDetail,
    getAll: function () {
      return destinations.slice();
    },
    getById: function (id) {
      return byId.get(id) || null;
    },
    getContinent: function (id) {
      return CONTINENTS.find((c) => c.id === id) || CONTINENTS[0];
    }
  };
})(window);
